"""、

默认的组件库（模板）

-------------
作者：XiangQinxi
-------------
"""

from .badge import DBadge
from .button import DButton
from .entry import DEntry
from .frame import DFrame
from .label import DLabel
from .text import DText
from .window import DWindow
