class DDraw(object):
    def create_tk_svglib_image(self, path):
        from reportlab.graphics import renderPM
        from svglib.svglib import svg2rlg
        from os import path

        tempfilepath, tempfilename = os.path.split(path)
        tempfilename2, tempextension = os.path.splitext(tempfilename)
        filepath = path.join(tempfilepath, tempfilename2+".png")

        drawing = svg2rlg(path)
        renderPM.drawToFile(drawing, filepath, fmt="PNG")

        return self.create_tk_image(filepath)

    def create_tksvg_image(self, path):
        from tksvg import SvgImage
        tkimage = SvgImage(file=path)
        return tkimage

    def create_tk_image(self, path):
        from PIL.Image import open
        from PIL.ImageTk import PhotoImage
        image = open(path)
        tkimage = PhotoImage(image=image)
        return tkimage

    """def svg_to_png(self, svgpath):
        import cairosvg
        from tempfile import mkstemp
        _, path = mkstemp(suffix=".png", prefix="tkdeft.temp.")
        cairosvg.svg2png(file_obj=open(svgpath), write_to=path)
        return path
    """


class DSvgDraw(DDraw):
    def create_drawing(self, width, height, temppath=None):
        if temppath:
            path = temppath
        else:
            from tempfile import mkstemp
            _, path = mkstemp(suffix=".svg", prefix="tkdeft.temp.")
        import svgwrite
        dwg = svgwrite.Drawing(path, width=width, height=height)

        return path, dwg
